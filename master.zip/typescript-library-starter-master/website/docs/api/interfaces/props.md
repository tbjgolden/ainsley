---
id: "props"
title: "Props"
sidebar_label: "Props"
---

[gocvmmeyaahgakggbjwmcmif](../index.md) › [Props](props.md)

## Hierarchy

* **Props**

## Index

### Properties

* [text](props.md#text)

## Properties

###  text

• **text**: *string*

*Defined in [index.ts:5](https://github.com/tbjgolden/typescript-library-starter/blob/6e6130c/src/index.ts#L5)*
