---
id: "index"
title: "gocvmmeyaahgakggbjwmcmif"
sidebar_label: "Globals"
---

[gocvmmeyaahgakggbjwmcmif](index.md)

## Index

### Interfaces

* [Props](interfaces/props.md)

### Functions

* [C](index.md#const-c)
* [id](index.md#const-id)

## Functions

### `Const` C

▸ **C**(`__namedParameters`: object): *Element‹›*

*Defined in [index.ts:8](https://github.com/tbjgolden/typescript-library-starter/blob/6e6130c/src/index.ts#L8)*

**Parameters:**

▪ **__namedParameters**: *object*

Name | Type |
------ | ------ |
`text` | string |

**Returns:** *Element‹›*

___

### `Const` id

▸ **id**(`prefix`: string): *string*

*Defined in [index.ts:14](https://github.com/tbjgolden/typescript-library-starter/blob/6e6130c/src/index.ts#L14)*

**Parameters:**

Name | Type | Default |
------ | ------ | ------ |
`prefix` | string | "id" |

**Returns:** *string*
