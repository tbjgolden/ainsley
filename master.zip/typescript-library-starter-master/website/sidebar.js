module.exports = {
  sidebar: {
    Docusaurus: ['doc1', 'doc2', 'doc3', 'mdx'],
    API: ['api/index']
  }
}
